$(document).ready(function() {
	$(".mobile-menu").on('click', function(){
		$(".mobile-dropdown").slideToggle("fast");
	});
});